package com.sg.classroster.dao;

//'Extend' keyword to indicate we are extending exception
public class ClassRosterPersistenceException extends Exception{

    //constructor that only takes String message
    public ClassRosterPersistenceException(String message) {
        super(message);
    }

    //constructor that take message and throwable cause
    public ClassRosterPersistenceException(String message, Throwable cause) {
        super(message, cause);
    }
}
