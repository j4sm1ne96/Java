package com.sg.vendingmachine;

public class Change {
    private int amountMinusPrice;

    private int twoPoundCoins; //num of 2 pound coins returned
    private int onePoundCoins; //num of 1 pound coins returned
    private int fiftyPennyCoins; //num of 50p returned
    private int twentyPennyCoins; // num of 20p returned
    private int tenPennyCoins; // num of 10p returned

    //constructors
    public Change() {
    }

    public Change(int amountMinusPrice) {
        this.amountMinusPrice = amountMinusPrice;
    }

    //Getters & Setters

    public int getAmountMinusPrice() {
        return amountMinusPrice;
    }

    public void setAmountMinusPrice(int amountMinusPrice) {
        this.amountMinusPrice = amountMinusPrice;
    }

    public int getTwoPoundCoins() {
        return twoPoundCoins;
    }

    public void setTwoPoundCoins(int twoPoundCoins) {
        this.twoPoundCoins = twoPoundCoins;
    }

    public int getOnePoundCoins() {
        return onePoundCoins;
    }

    public void setOnePoundCoins(int onePoundCoins) {
        this.onePoundCoins = onePoundCoins;
    }

    public int getFiftyPennyCoins() {
        return fiftyPennyCoins;
    }

    public void setFiftyPennyCoins(int fiftyPennyCoins) {
        this.fiftyPennyCoins = fiftyPennyCoins;
    }

    public int getTwentyPennyCoins() {
        return twentyPennyCoins;
    }

    public void setTwentyPennyCoins(int twentyPennyCoins) {
        this.twentyPennyCoins = twentyPennyCoins;
    }

    public int getTenPennyCoins() {
        return tenPennyCoins;
    }

    public void setTenPennyCoins(int tenPennyCoins) {
        this.tenPennyCoins = tenPennyCoins;
    }

    @Override
    public String toString() {
        return "Your change is..." +
                "amountMinusPrice = " + amountMinusPrice +
                ", twoPoundCoins = " + twoPoundCoins +
                ", onePoundCoins = " + onePoundCoins +
                ", fifty Penny coins = " + fiftyPennyCoins +
                ", twenty penny coins = " + twentyPennyCoins +
                ", ten penny coins = " + tenPennyCoins +
                ":";
    }

    // Method to calculate the change

    public void ChangeCalculation() {
        this.twoPoundCoins = this.amountMinusPrice / Currency.TWOPOUNDCOIN.getWorth();
        int remainder = this.amountMinusPrice % Currency.TWOPOUNDCOIN.getWorth();
        this.onePoundCoins = remainder / Currency.ONEPOUNDCOIN.getWorth();
        int remainderTwo = remainder % Currency.ONEPOUNDCOIN.getWorth();
        this.fiftyPennyCoins = remainderTwo / Currency.FIFTYPENCE.getWorth();
        int remainderThree = remainderTwo % Currency.FIFTYPENCE.getWorth();
        this.twentyPennyCoins = remainderThree / Currency.TWENTYPENCE.getWorth();
        int remainderFour = remainderThree % Currency.TWENTYPENCE.getWorth();
        this.tenPennyCoins = remainderFour / Currency.TENPENCE.getWorth();
        int finalRemainder = remainderFour % Currency.TENPENCE.getWorth();

        System.out.println(this.toString());
        System.out.println("Remainder = " + finalRemainder);

    }

    public static void Logo() {
        System.out.println("====================");
        System.out.println("======Vending======");
        System.out.println("======CHANGE======");
    }
}//end of class
