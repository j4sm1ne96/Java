package com.sg.vendingmachine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Scanner;

@Component
public class Controller {

    private InventoryTracker track;

    @Autowired
    public Controller(InventoryTracker track) {
        this.track = track;
    }

    public void run() {

        //declare a new object of class com.sg.vendingmachine.InventoryTracker
        track.readFile("items.txt");
        System.out.println(track.getInventoryList());

        //Step 1) Scanner for if customer wants to use the vending machine

        Scanner itemWanted = new Scanner(System.in);
        System.out.println("Do you want an item? 1 = Yes, 2 = no");

        int want = Integer.parseInt(itemWanted.nextLine());

        if (want == 2) {
            System.out.println("No problem, have a great day!");
            System.exit(0);
        } else {
            //Step 2) Scanner to ask for money input
            Scanner inputMoney = new Scanner(System.in);
            System.out.println("Enter money for the item you would like (enter in pence e.g. '200')");
            double amountEntered = Double.parseDouble(inputMoney.nextLine());

            //Step 3) Scanner to ask which item user would like
            Scanner userItem = new Scanner(System.in);
            System.out.println("Type in the id of the item you would like: ");
            System.out.println("1: Mars bar");
            System.out.println("2: Starbar");
            System.out.println("3: Crisps");
            System.out.println("4: Coke");
            System.out.println("5: TicTac");

            int itemSelected = Integer.parseInt(userItem.nextLine());

            if (itemSelected > 5 | itemSelected < 0) {
                System.out.println("We do not have this item");
            } else if (track.getInventoryList().get(itemSelected - 1).getInventory() == 0) {
                System.out.println("This item is out of stock");
            } else {

                //access the price of the item selected by the user, save in variable
                double priceOfItem = track.getInventoryList().get(itemSelected - 1).getPrice();

                if (priceOfItem > amountEntered) {
                    System.out.println("You only entered: " + amountEntered + " but the price of your item is: " + priceOfItem + " please enter: " + (priceOfItem - amountEntered));
                    Scanner inputMoney2 = new Scanner(System.in);
                    double amountEntered2 = Double.parseDouble(inputMoney2.nextLine());

                    amountEntered = amountEntered + amountEntered2;
                }

                //Calculate change

                System.out.println("Thank you for your purchase!");

                double difference = amountEntered - priceOfItem;

                if (difference > 0) {

                    Change.Logo();

                    Change userChange = new Change((int) difference);

                    userChange.ChangeCalculation();
                }

                //Write to file
                track.getInventoryList().get(itemSelected - 1).removeInventory();
                track.writeFile("items.txt");

                System.out.println(track.getInventoryList());


            }

        }
    }
}//end of run
