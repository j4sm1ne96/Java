package com.sg.vendingmachine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.ArrayList;
import java.io.FileInputStream;

@Component
public class InventoryTracker {
    private ArrayList<Items> inventoryList = new ArrayList<>();
    private String filePath = "src/main/java/com/sg/vendingmachine/";

    @Autowired
    // Constructor
    public InventoryTracker() {
    }

    //Constructor with the array of items as a parameter

    public InventoryTracker(ArrayList<Items> inventoryList) {
        this.inventoryList = inventoryList;
    }

    //Method to return ArrayList
    public ArrayList<Items> getInventoryList() {
        return inventoryList;
    }

    //Method to add item to itemArray
    public boolean addItems(Items item) {
        if(inventoryList.contains(item)) {
            this.findByName(item.name).addCopy();
        } else {
            inventoryList.add(item);
        }
        return true;
    }

    //Method to find item based on name

    public Items findByName(String name) {
        for(Items itemTemp : inventoryList) {
            if(itemTemp.getName().equals(name)) {
                return itemTemp;
            }
        }
        return null;
    }

    //Method to find item based on ID

    public Items findById(int id) {
        for(Items idTemp: inventoryList) {
            if(idTemp.getId() == id) {
                return idTemp;
            }
        }
        return null;
    }

    //Method to minus from inventory

    public void minusInventory(Items newInventory) {
        int counter = newInventory.getInventory();
        for (Items inventoryTemp: inventoryList) {
            if(newInventory.getName().equals(inventoryTemp.getName())) {
                counter--;
            }
            if (counter == 0) {
                System.out.println("There are no more of these items in stock");
            }
        }
    }

    //Method to bring in items from file
    public void readFile(String fileName) {
        //clear array before bringing in items
        inventoryList.clear();
        try {
            //array to store the lines from the file
            ArrayList<String> lines = new ArrayList<>();

            System.out.println();
            //create an input stream of the file
            FileInputStream fis = new FileInputStream(filePath + fileName);
            //create a buffered reader of the file
            BufferedReader br = new BufferedReader(new InputStreamReader(fis));

            String line;
            //loops through the lines from the file
            while((line = br.readLine()) != null) {
                lines.add(line);
            } //end of while

            //Initialise an array to store each individual value of the items
            ArrayList<String[]> itemValues = new ArrayList<>();

            //loop through each line and add each part to the itemValues array, split by comma
            for(int i = 0; i < lines.size(); i++) {
                itemValues.add(lines.get(i).split(","));
            }
            //loop through each line and add an item to the array of items
            for(String[] listOfValues: itemValues) {
                addItems((new Items(listOfValues[0], listOfValues[1], listOfValues[2], listOfValues[3])));
            }
            //close file
            br.close();
        } catch (IOException|IndexOutOfBoundsException|IllegalArgumentException e) {
            e.printStackTrace();
        }
    }
    public void printItems() {
        for(Items items: inventoryList) {
            System.out.println(items);
        }
    }

    //2nd attempt to write to the file, but also throws an error
    public void writeFile(String fileName) {

        try {
            //Create a writer to the file
            BufferedWriter bw = new BufferedWriter(new FileWriter(filePath + fileName, true));
            //Create a printer to the file
            PrintWriter pw = new PrintWriter(filePath+fileName);
            //Empty the current file
            pw.print("");

            //loop through each item in the inventoryList array

            for(Items item: inventoryList) {
                bw.append(item.toStringFileWriting() + "\n");
            }
            //close file
            bw.close();

        } catch (IOException|IndexOutOfBoundsException|IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

}
