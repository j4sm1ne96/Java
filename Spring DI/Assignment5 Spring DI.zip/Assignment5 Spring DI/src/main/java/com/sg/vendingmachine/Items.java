package com.sg.vendingmachine;

public class Items {

    public int id;
    public String name;
    public double price;
    public int inventory;

    //constructors


    public Items(String name) {
        this.name = name;
    }

    public Items(int id, String name, double price, int inventory) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.inventory = inventory;
    }

    //Converting variables to Strings
    public Items(String id, String name, String price, String inventory) {
        int newId = Integer.parseInt(id.trim());
        String newName = name.trim();
        double newPrice = Double.parseDouble(price.trim());
        int newInventory = Integer.parseInt(inventory.trim());

        this.id = newId;
        this.name = newName;
        this.price = newPrice;
        this.inventory = newInventory;
    }

    //getters & setters


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public String getPriceFormatted() {
        return String.format("£%,.2f", price/100);
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getInventory() {
        return inventory;
    }

    public void setInventory(int inventory) {
        this.inventory = inventory;
    }

    public void removeInventory() {
        inventory--;
    }

    //Method to add copy
    public void addCopy() {

    }


    @Override
    public String toString() {
        return "{" + id + ": " + name + ", Price: " + getPriceFormatted() + ", " + inventory + "}";
    }
    //Part of 2nd attempt to write to file
    public String toStringFileWriting() {
        return String.format("%s,%s,%s,%s",id,name,price,inventory);
    }
}
