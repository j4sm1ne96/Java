package com.sg.vendingmachine;

public enum Currency {
    TWOPOUNDCOIN(200), ONEPOUNDCOIN(100), FIFTYPENCE(50), TWENTYPENCE(20), TENPENCE(10);
    private int worth;

    Currency(int worth) {
        this.worth = worth;
    }

    //getters and setters

    public int getWorth() {
        return worth;
    }

    public void setWorth(int worth) {
        this.worth = worth;
    }
}
