package com.sg.classroster;

import com.sg.classroster.controller.ClassRosterController;
import com.sg.classroster.dao.ClassRosterDaoFileImpl;
import com.sg.classroster.ui.ClassRosterView;
import com.sg.classroster.ui.UserIO;
import com.sg.classroster.ui.UserIOConsoleImpl;

public class App {
    //creating dependency injection in App
    public static void main(String[] args) {
        //1) declare a userIo variable and initialise it with UserIOConsoleImpl reference
        UserIO myIo = new UserIOConsoleImpl();
        //2) Declare and instantiate ClassRosterView object
        ClassRosterView myView = new ClassRosterView(myIo);
        //3) Declare a ClassRosterDao variable and initialise it with ClassRosterDaoFileImpl reference
        ClassRosterDaoFileImpl myDao = new ClassRosterDaoFileImpl();
        //4) Instantiate a ClassRosterController, passing ClassRosterDao and ClassRosterView object into constructor
        ClassRosterController controller = new ClassRosterController(myView, myDao);
        controller.run();
    }
}
