package com.sg.classroster.dao;

//'Extend' keyword to indicate we are extending exception
public class ClassRosterDaoException extends Exception{

    //constructor that only takes String message
    public ClassRosterDaoException(String message) {
        super(message);
    }

    //constructor that take message and throwable cause
    public ClassRosterDaoException(String message, Throwable cause) {
        super(message, cause);
    }
}
