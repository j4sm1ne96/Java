package Assessment2;
import java.io.*;
import java.util.ArrayList;
import java.io.FileInputStream;

public class DVDCollections {
    //Stores the array of DVDs
    private ArrayList<DVD> dvdArray = new ArrayList<>();
    //File path of file
    private String filePath = "src/Assessment2/";

    //Constructor

    public DVDCollections(){

    }
    //Constructor with the array of DVDs as a parameter
    public DVDCollections(ArrayList<DVD> dvdArrayList) {
        this.dvdArray = dvdArray;
    }

    //method to return ArrayList
    public ArrayList<DVD> getDvdArray() {
        return dvdArray;
    }

    //method to add a dvd parameter to the dvdArray

    public boolean addDVD(DVD dvd) {
        if(dvdArray.contains(dvd)) {
            this.findByTitle(dvd.title).addCopy();
        } else {
            dvdArray.add(dvd);
        }
        return true;
    }

    //method to add dvd to the dvdArray with title as a parameter

    public boolean addDVD(String title) {
        //tries to add a DVD with just the title, or false if this fails
        try {
            return addDVD(new DVD(title));
        } catch (Exception e){
            return false;
        }
    }

    //method to remove dvd from dvdArray with title as parameter
    public void removeDVD(DVD dvd) {
        for (DVD dvdTemp : dvdArray) {
            if(dvd.getTitle().equals(dvdTemp.getTitle())){
                dvdArray.remove(dvdTemp);
            }
        }
    }


    //Method to find DVD based on title

    public DVD findByTitle(String title) {
        for(DVD dvdTemp : dvdArray) {
            if(dvdTemp.getTitle().equals(title)) {
                return dvdTemp;
            }
        }
        return null;
    }

    //Method to bring dvds into dvdArray from file

    public void readFile(String fileName) {
        //clears array before loading dvds
        dvdArray.clear();
        try {
            //array to store the lines from the file
            ArrayList<String> lines = new ArrayList<>();

            System.out.println();
            //create an input stream of the file
            FileInputStream fis = new FileInputStream(filePath + fileName);
            //create a buffered reader of the file
            BufferedReader br = new BufferedReader(new InputStreamReader(fis));

            String line;
            //loops through the lines from the file
            while((line = br.readLine()) != null) {
                lines.add(line);
            } //end of while

            //Initialise an array to store each individual value to create DVD from
            ArrayList<String[]> dvdValues = new ArrayList<>();

            //loop through each line and add each part to the dvdValues array, split by comma
            for(int i = 0; i < lines.size(); i++) {
                dvdValues.add(lines.get(i).split(","));
            }
            //loop through each line and add a dvd to the array of dvds
            for(String[] listOfValues: dvdValues) {
                addDVD(new DVD(listOfValues[0], listOfValues[1], listOfValues[2], listOfValues[3], listOfValues[4], listOfValues[5]));
            }
            //close file
            br.close();
        } catch (IOException|IndexOutOfBoundsException|IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

    //Method to find DVD

    public DVD findDVD(String title) {
        //Loops through each DVD in the array of DVDs
        for(DVD dvdTemp : dvdArray) {
            //Returns the DVD if the title is equal to the input
            if(dvdTemp.title.equals(title)) {
                return dvdTemp;
            }
        }
        return null;
    }


    //methods to edit files
    public void editTitle(String title, String newTitle) {
        findDVD(title).setTitle(newTitle);
    }

    public void editReleaseDate(String title, String newDate) {
        findDVD(title).setTitle(newDate);
    }

    public void editMPAA(String title, String newMPAA) {
        findDVD(title).setTitle(newMPAA);
    }

    public void editDirector(String title, String newDirector) {
        findDVD(title).setTitle(newDirector);
    }

    public void editStudio(String title, String newStudio) {
        findDVD(title).setTitle(newStudio);
    }

    public void editRating(String title, String newRating) {
        findDVD(title).setTitle(newRating);
    }


    //Return the collection of DVDs as a formatted string
    @Override
    public String toString() {
        return dvdArray.toString();
    }

}
