package Assessment2;

import java.util.Scanner;

public class Main {

 public static void main(String[] args) {
  //declare a new object of class DVDCollection
  DVDCollections a = new DVDCollections();
  a.readFile("dvd.txt");
  System.out.println(a.getDvdArray());

  Scanner userInput = new Scanner(System.in);
  System.out.println("Make a choice from the menu: ");
  System.out.println("1: Add DVD");
  System.out.println("2: Remove DVD");
  System.out.println("3: Edit DVD");
  System.out.println("4: View Collection DVD");
  System.out.println("5: View DVD");

  int userOption = userInput.nextInt();
  String ignore = userInput.nextLine();

  String userInputTitle = "";
  String userInputDate = "";
  String userInputMPAA = "";
  String userInputDirector = "";
  String userInputStudio = "";
  String userInputRating = "";

  switch (userOption) {
   case 1: // Add DVD
    System.out.println("Enter DVD Title: ");
    userInputTitle = userInput.nextLine();

    System.out.println("Enter release date: ");
    userInputDate = userInput.nextLine();

    System.out.println("Enter MPAA rating: ");
    userInputMPAA = userInput.nextLine();

    System.out.println("Enter Director name: ");
    userInputDirector = userInput.nextLine();

    System.out.println("Enter studio name: ");
    userInputStudio = userInput.nextLine();

    System.out.println("Enter user rating: ");
    userInputRating = userInput.nextLine();

    DVD newInput = new DVD(userInputTitle, userInputDate, userInputMPAA, userInputDirector, userInputStudio, userInputRating);

    break;

   case 2: // Remove DVD
    System.out.println("You chose 2");
    System.out.println("Enter DVD Title: ");
    userInputTitle = userInput.nextLine();
    a.removeDVD(new DVD(userInputTitle));
    break;

   case 3: // Edit DVD
    System.out.println("Enter DVD Title: ");
    userInputTitle = userInput.nextLine();
    System.out.println(a.findDVD(userInputTitle));
    System.out.println("Make a choice from the menu: ");
     System.out.println("1: Edit title");
     System.out.println("2: Edit date");
     System.out.println("3: Edit MPAA rating");
     System.out.println("4: Edit director name");
     System.out.println("5: Edit studio");
     System.out.println("6: Edit rating");

     userOption = userInput.nextInt();
     switch (userOption) {
      case 1:
       System.out.println("Enter NEW Title: ");
       String newUserInputTitle = userInput.nextLine();
       a.editTitle(userInputTitle, newUserInputTitle);
       break;
      case 2:
       System.out.println("Enter NEW date");
       String newUserInputDate = userInput.nextLine();
       a.editReleaseDate(userInputDate, newUserInputDate);
       break;
      case 3:
       System.out.println("Enter NEW MPAA");
       String newUserInputMPAA = userInput.nextLine();
       a.editMPAA(userInputMPAA, newUserInputMPAA);
       break;
      case 4:
       System.out.println("Enter NEW Director");
       String newUserInputDirector = userInput.nextLine();
       a.editDirector(userInputDirector, newUserInputDirector);
       break;
      case 5:
       System.out.println("Enter NEW Studio");
       String newUserInputStudio = userInput.nextLine();
       a.editStudio(userInputStudio, newUserInputStudio);
       break;
      case 6:
       System.out.println("Enter NEW rating");
       String newUserInputRating = userInput.nextLine();
       a.editRating(userInputRating, newUserInputRating);
       break;

     }
    break;

   case 4: // View Collection
    System.out.println(a.getDvdArray());
    break;

   case 5: // View DVD
    System.out.println("Enter DVD Title");
    userInputTitle = userInput.nextLine();
    System.out.println(a.findDVD(userInputTitle));
  }




 }// end of main

}//end of class
