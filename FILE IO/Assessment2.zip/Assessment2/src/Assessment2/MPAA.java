package Assessment2;

public enum MPAA {
    //The values for MPAA ratings
    G("General"), PG("Parental Guidance"), PG13("13 and above"), R("Restricted"), NC17("No one 17 and under admitted"), EMPTY("Empty rating");
    String value;

    MPAA(String i) {
        value = i;
    }
}




